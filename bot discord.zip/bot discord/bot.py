"""
Discord stats & badge bot (discord.py 2.x)

Features
  /members                      Server member count
  /messages [user]              Messages a user sent in the monitored channels
  /leaderboard                  Top 10 senders in the monitored channels
  /monitor setup|all|list|clear|backfill   Choose which channels are tracked
  /badge [user]                 Image of the user's profile badges
  /nitro [user]                 Nitro months + current/next badge image
  /nitro_set <YYYY-MM-DD>       Register your own Nitro start date (see README)
  /nitro_forget                 Delete your registered date
  /boost [user]                 Server-boost months in THIS server + badge image

No privileged intents are required.
"""
import asyncio
import calendar
import io
import logging
import math
import os
import sqlite3
import zlib
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv
from PIL import Image, ImageDraw, ImageFont

load_dotenv()

TOKEN = os.getenv("DISCORD_TOKEN")
DEV_GUILD_ID = os.getenv("DEV_GUILD_ID")  # optional: instant command sync in one server
DB_PATH = os.getenv("DB_PATH", "botdata.sqlite3")
BADGE_DIR = Path(os.getenv("BADGE_DIR", "badges"))

UTC = timezone.utc
log = logging.getLogger("statsbot")


# --------------------------------------------------------------------------- #
# Badge / tier definitions
# --------------------------------------------------------------------------- #
def _months_label(m: int) -> str:
    if m % 12 == 0:
        y = m // 12
        return f"{y} year{'s' if y > 1 else ''}"
    return f"{m} month{'s' if m > 1 else ''}"


# (months required, display text, icon file stem inside BADGE_DIR)
# Thresholds are editable here if Discord changes them.
NITRO_TIERS = [(0, "Subscriber (under 1 month)", "nitro_base")] + [
    (m, f"{name} ({_months_label(m)})", f"nitro_{name.lower()}")
    for m, name in [
        (1, "Bronze"), (3, "Silver"), (6, "Gold"), (12, "Platinum"),
        (24, "Diamond"), (36, "Emerald"), (60, "Ruby"), (72, "Fire"),
    ]
]

BOOST_TIERS = [(0, "Booster (under 1 month)", "boost_0")] + [
    (m, f"Booster ({_months_label(m)})", f"boost_{m}")
    for m in (1, 2, 3, 6, 9, 12, 15, 18, 24)
]

# Badges Discord exposes to bots through `user.public_flags`.
# (discord.py attribute, icon file stem, label)
FLAG_BADGES = [
    ("staff", "discord_staff", "Discord Staff"),
    ("partner", "partner", "Partnered Server Owner"),
    ("discord_certified_moderator", "certified_moderator", "Moderator Programs Alumni"),
    ("hypesquad", "hypesquad_events", "HypeSquad Events"),
    ("hypesquad_bravery", "hypesquad_bravery", "HypeSquad Bravery"),
    ("hypesquad_brilliance", "hypesquad_brilliance", "HypeSquad Brilliance"),
    ("hypesquad_balance", "hypesquad_balance", "HypeSquad Balance"),
    ("bug_hunter", "bug_hunter_1", "Bug Hunter"),
    ("bug_hunter_level_2", "bug_hunter_2", "Bug Hunter Gold"),
    ("early_supporter", "early_supporter", "Early Supporter"),
    ("verified_bot_developer", "verified_developer", "Early Verified Bot Developer"),
    ("active_developer", "active_developer", "Active Developer"),
    ("verified_bot", "verified_app", "Verified App"),
]


# --------------------------------------------------------------------------- #
# Date helpers
# --------------------------------------------------------------------------- #
def add_months(dt: datetime, n: int) -> datetime:
    y = dt.year + (dt.month - 1 + n) // 12
    m = (dt.month - 1 + n) % 12 + 1
    d = min(dt.day, calendar.monthrange(y, m)[1])
    return dt.replace(year=y, month=m, day=d)


def full_months(start: datetime, now: datetime) -> int:
    m = (now.year - start.year) * 12 + now.month - start.month
    if add_months(start, m) > now:
        m -= 1
    return max(m, 0)


def tier_for(tiers, months: int):
    """Return (current_tier, next_tier_or_None)."""
    current = tiers[0]
    nxt = None
    for tier in tiers:
        if tier[0] <= months:
            current = tier
        else:
            nxt = tier
            break
    return current, nxt


def humanize(td) -> str:
    total = max(int(td.total_seconds()), 0)
    days, rem = divmod(total, 86400)
    hours = rem // 3600
    return f"{days}d {hours}h"


# --------------------------------------------------------------------------- #
# Database
# --------------------------------------------------------------------------- #
class Database:
    def __init__(self, path: str):
        self.conn = sqlite3.connect(path)
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS monitored_channels (
                guild_id   INTEGER NOT NULL,
                channel_id INTEGER NOT NULL,
                PRIMARY KEY (guild_id, channel_id)
            );
            CREATE TABLE IF NOT EXISTS message_counts (
                guild_id   INTEGER NOT NULL,
                channel_id INTEGER NOT NULL,
                user_id    INTEGER NOT NULL,
                count      INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY (guild_id, channel_id, user_id)
            );
            CREATE TABLE IF NOT EXISTS nitro_since (
                user_id INTEGER PRIMARY KEY,
                since   TEXT NOT NULL
            );
            """
        )
        self.conn.commit()

    # -- monitored channels
    def load_monitored(self) -> dict:
        out: dict = {}
        for g, c in self.conn.execute("SELECT guild_id, channel_id FROM monitored_channels"):
            out.setdefault(g, set()).add(c)
        return out

    def set_monitored(self, guild_id: int, channel_ids) -> None:
        with self.conn:
            self.conn.execute("DELETE FROM monitored_channels WHERE guild_id = ?", (guild_id,))
            self.conn.executemany(
                "INSERT INTO monitored_channels (guild_id, channel_id) VALUES (?, ?)",
                [(guild_id, c) for c in channel_ids],
            )

    # -- counting
    def increment(self, guild_id: int, channel_id: int, user_id: int) -> None:
        with self.conn:
            self.conn.execute(
                """INSERT INTO message_counts (guild_id, channel_id, user_id, count)
                   VALUES (?, ?, ?, 1)
                   ON CONFLICT (guild_id, channel_id, user_id)
                   DO UPDATE SET count = count + 1""",
                (guild_id, channel_id, user_id),
            )

    def replace_channel_counts(self, guild_id: int, channel_id: int, counts: Counter) -> None:
        with self.conn:
            self.conn.execute(
                "DELETE FROM message_counts WHERE guild_id = ? AND channel_id = ?",
                (guild_id, channel_id),
            )
            self.conn.executemany(
                "INSERT INTO message_counts (guild_id, channel_id, user_id, count) VALUES (?, ?, ?, ?)",
                [(guild_id, channel_id, uid, n) for uid, n in counts.items()],
            )

    # Queries only look at channels that are currently monitored.
    def user_stats(self, guild_id: int, user_id: int):
        return self.conn.execute(
            """SELECT c.channel_id, c.count
               FROM message_counts c
               JOIN monitored_channels m
                 ON m.guild_id = c.guild_id AND m.channel_id = c.channel_id
               WHERE c.guild_id = ? AND c.user_id = ?
               ORDER BY c.count DESC""",
            (guild_id, user_id),
        ).fetchall()

    def leaderboard(self, guild_id: int, limit: int = 10):
        return self.conn.execute(
            """SELECT c.user_id, SUM(c.count) AS total
               FROM message_counts c
               JOIN monitored_channels m
                 ON m.guild_id = c.guild_id AND m.channel_id = c.channel_id
               WHERE c.guild_id = ?
               GROUP BY c.user_id
               ORDER BY total DESC
               LIMIT ?""",
            (guild_id, limit),
        ).fetchall()

    def total_messages(self, guild_id: int) -> int:
        row = self.conn.execute(
            """SELECT COALESCE(SUM(c.count), 0)
               FROM message_counts c
               JOIN monitored_channels m
                 ON m.guild_id = c.guild_id AND m.channel_id = c.channel_id
               WHERE c.guild_id = ?""",
            (guild_id,),
        ).fetchone()
        return int(row[0])

    # -- nitro (self-registered)
    def set_nitro_since(self, user_id: int, since: datetime) -> None:
        with self.conn:
            self.conn.execute(
                """INSERT INTO nitro_since (user_id, since) VALUES (?, ?)
                   ON CONFLICT (user_id) DO UPDATE SET since = excluded.since""",
                (user_id, since.isoformat()),
            )

    def get_nitro_since(self, user_id: int) -> Optional[datetime]:
        row = self.conn.execute(
            "SELECT since FROM nitro_since WHERE user_id = ?", (user_id,)
        ).fetchone()
        return datetime.fromisoformat(row[0]) if row else None

    def forget_nitro(self, user_id: int) -> None:
        with self.conn:
            self.conn.execute("DELETE FROM nitro_since WHERE user_id = ?", (user_id,))


# --------------------------------------------------------------------------- #
# Image rendering (Pillow)
# --------------------------------------------------------------------------- #
BG = (32, 34, 37)
TEXT = (255, 255, 255)
MUTED = (163, 166, 170)

_font_cache: dict = {}


def get_font(size: int, bold: bool = False):
    key = (size, bold)
    if key in _font_cache:
        return _font_cache[key]
    candidates = (
        ["DejaVuSans-Bold.ttf", "arialbd.ttf",
         "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
         "/System/Library/Fonts/Supplemental/Arial Bold.ttf"]
        if bold
        else ["DejaVuSans.ttf", "arial.ttf",
              "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
              "/System/Library/Fonts/Supplemental/Arial.ttf"]
    )
    font = None
    for name in candidates:
        try:
            font = ImageFont.truetype(name, size)
            break
        except OSError:
            continue
    if font is None:
        try:
            font = ImageFont.load_default(size)
        except TypeError:  # very old Pillow
            font = ImageFont.load_default()
    _font_cache[key] = font
    return font


def text_size(draw, text, font):
    l, t, r, b = draw.textbbox((0, 0), text, font=font)
    return r - l, b - t, l, t


def draw_centered(draw, cx, cy, text, font, fill):
    w, h, l, t = text_size(draw, text, font)
    draw.text((cx - w / 2 - l, cy - h / 2 - t), text, font=font, fill=fill)


def wrap_text(draw, text, font, max_w):
    lines, cur = [], ""
    for word in text.split():
        trial = f"{cur} {word}".strip()
        if not cur or text_size(draw, trial, font)[0] <= max_w:
            cur = trial
        else:
            lines.append(cur)
            cur = word
    if cur:
        lines.append(cur)
    return lines


def color_for(key: str):
    h = zlib.crc32(key.encode())
    return (80 + (h & 0xFF) % 140, 80 + ((h >> 8) & 0xFF) % 140, 80 + ((h >> 16) & 0xFF) % 140)


def placeholder_icon(key: str, label: str, size: int):
    """Coloured circle with initials, used when no PNG exists in BADGE_DIR."""
    scale = 4
    big = size * scale
    img = Image.new("RGBA", (big, big), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.ellipse((0, 0, big - 1, big - 1), fill=color_for(key))
    cleaned = label.replace("(", " ").replace(")", " ")
    initials = "".join(w[0] for w in cleaned.split()[:2]).upper() or "?"
    draw_centered(d, big / 2, big / 2, initials, get_font(int(big * 0.36), bold=True), (255, 255, 255, 255))
    return img.resize((size, size), Image.Resampling.LANCZOS)


def load_icon(key: str, label: str, size: int):
    path = BADGE_DIR / f"{key}.png"
    if path.is_file():
        try:
            return Image.open(path).convert("RGBA").resize((size, size), Image.Resampling.LANCZOS)
        except Exception:
            log.exception("Could not read badge icon %s", path)
    return placeholder_icon(key, label, size)


def make_avatar(avatar_bytes: Optional[bytes], size: int):
    if avatar_bytes:
        try:
            img = Image.open(io.BytesIO(avatar_bytes)).convert("RGBA").resize((size, size), Image.Resampling.LANCZOS)
            big = size * 4
            mask = Image.new("L", (big, big), 0)
            ImageDraw.Draw(mask).ellipse((0, 0, big - 1, big - 1), fill=255)
            img.putalpha(mask.resize((size, size), Image.Resampling.LANCZOS))
            return img
        except Exception:
            log.exception("Could not read avatar")
    return placeholder_icon("avatar", "?", size)


def _png(img) -> bytes:
    buf = io.BytesIO()
    img.convert("RGB").save(buf, "PNG")
    return buf.getvalue()


def render_badges_image(name: str, avatar_bytes: Optional[bytes], badges: list) -> bytes:
    """badges: list of (icon_key, label)."""
    cols = max(1, min(5, len(badges)))
    rows = max(1, math.ceil(len(badges) / cols))
    cell_w, cell_h, icon = 150, 170, 96
    pad, header_h = 28, 140
    width = max(cols * cell_w + pad * 2, 560)
    height = header_h + rows * cell_h + pad

    img = Image.new("RGBA", (width, height), BG + (255,))
    d = ImageDraw.Draw(img)

    avatar = make_avatar(avatar_bytes, 88)
    img.paste(avatar, (pad, pad), avatar)
    d.text((pad + 88 + 22, pad + 8), name[:28], font=get_font(30, bold=True), fill=TEXT)
    d.text((pad + 88 + 22, pad + 52), f"{len(badges)} badge{'s' if len(badges) != 1 else ''}",
           font=get_font(18), fill=MUTED)
    d.line((pad, header_h - 10, width - pad, header_h - 10), fill=(60, 63, 68), width=2)

    small = get_font(15)
    if not badges:
        draw_centered(d, width / 2, header_h + 50, "No badges found", get_font(22), MUTED)

    for i, (key, label) in enumerate(badges):
        r, c = divmod(i, cols)
        in_row = min(cols, len(badges) - r * cols)
        x0 = (width - in_row * cell_w) / 2 + c * cell_w
        y0 = header_h + r * cell_h
        ico = load_icon(key, label, icon)
        img.paste(ico, (int(x0 + (cell_w - icon) / 2), int(y0 + 8)), ico)
        for j, line in enumerate(wrap_text(d, label, small, cell_w - 12)[:3]):
            draw_centered(d, x0 + cell_w / 2, y0 + 8 + icon + 20 + j * 19, line, small, TEXT)

    return _png(img)


def render_tier_image(name: str, avatar_bytes: Optional[bytes], heading: str,
                      current: tuple, nxt: Optional[tuple], footer: str) -> bytes:
    """current / nxt: (icon_key, label). nxt is None at the maximum tier."""
    width, height = 700, 400
    img = Image.new("RGBA", (width, height), BG + (255,))
    d = ImageDraw.Draw(img)

    avatar = make_avatar(avatar_bytes, 72)
    img.paste(avatar, (28, 24), avatar)
    d.text((28 + 72 + 18, 28), name[:28], font=get_font(28, bold=True), fill=TEXT)
    d.text((28 + 72 + 18, 66), heading, font=get_font(17), fill=MUTED)
    d.line((28, 114, width - 28, 114), fill=(60, 63, 68), width=2)

    icon, icon_y = 128, 140
    cap_font, label_font = get_font(15), get_font(17, bold=True)

    def slot(cx, caption, key, label, dim=False):
        ico = load_icon(key, label, icon)
        if dim:
            ico.putalpha(ico.getchannel("A").point(lambda v: int(v * 0.6)))
        img.paste(ico, (int(cx - icon / 2), icon_y), ico)
        draw_centered(d, cx, icon_y + icon + 20, caption.upper(), cap_font, MUTED)
        for j, line in enumerate(wrap_text(d, label, label_font, 260)[:2]):
            draw_centered(d, cx, icon_y + icon + 44 + j * 22, line, label_font, TEXT)

    if nxt:
        slot(190, "Current", *current)
        slot(510, "Next", *nxt, dim=True)
        cy = icon_y + icon // 2
        d.polygon([(322, cy - 8), (350, cy - 8), (350, cy - 22), (378, cy),
                   (350, cy + 22), (350, cy + 8), (322, cy + 8)], fill=MUTED)
    else:
        slot(width / 2, "Current (max tier)", *current)

    draw_centered(d, width / 2, height - 26, footer, get_font(18), TEXT)
    return _png(img)


# --------------------------------------------------------------------------- #
# Bot
# --------------------------------------------------------------------------- #
class StatsBot(commands.Bot):
    def __init__(self):
        # Default intents are enough: counting messages does NOT need the
        # privileged Message Content intent, and member counts don't need
        # the Server Members intent.
        super().__init__(command_prefix=commands.when_mentioned, intents=discord.Intents.default())
        self.db = Database(DB_PATH)
        self.monitored: dict = {}

    async def setup_hook(self):
        self.monitored = self.db.load_monitored()
        if DEV_GUILD_ID:
            guild = discord.Object(id=int(DEV_GUILD_ID))
            self.tree.copy_global_to(guild=guild)
            await self.tree.sync(guild=guild)
        else:
            await self.tree.sync()

    async def on_ready(self):
        log.info("Logged in as %s (%s) in %d guild(s)", self.user, self.user.id, len(self.guilds))


bot = StatsBot()


@bot.listen("on_message")
async def count_message(message: discord.Message):
    if message.guild is None or message.author.bot:
        return
    if message.channel.id in bot.monitored.get(message.guild.id, ()):
        bot.db.increment(message.guild.id, message.channel.id, message.author.id)


@bot.tree.error
async def on_app_command_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
    if isinstance(error, app_commands.MissingPermissions):
        msg = "You need the **Manage Server** permission to use that."
    else:
        log.exception("Command error", exc_info=error)
        msg = "Something went wrong running that command."
    try:
        if interaction.response.is_done():
            await interaction.followup.send(msg, ephemeral=True)
        else:
            await interaction.response.send_message(msg, ephemeral=True)
    except discord.HTTPException:
        pass


# --------------------------------------------------------------------------- #
# Shared helpers
# --------------------------------------------------------------------------- #
async def resolve_member(guild: Optional[discord.Guild], user_id: int) -> Optional[discord.Member]:
    if guild is None:
        return None
    member = guild.get_member(user_id)
    if member:
        return member
    try:
        return await guild.fetch_member(user_id)
    except discord.HTTPException:
        return None


async def read_avatar(user: discord.abc.User) -> Optional[bytes]:
    try:
        return await user.display_avatar.replace(size=256, format="png").read()
    except discord.HTTPException:
        return None


def ts(dt: datetime, style: str = "R") -> str:
    return f"<t:{int(dt.timestamp())}:{style}>"


async def send_tier_card(interaction: discord.Interaction, target: discord.abc.User, *, tiers, start: datetime,
                         heading: str, since_label: str, note: str):
    now = datetime.now(UTC)
    months = full_months(start, now)
    cur, nxt = tier_for(tiers, months)
    nxt_date = add_months(start, nxt[0]) if nxt else None

    if nxt:
        footer = f"{months} month{'s' if months != 1 else ''} so far  |  next badge in {humanize(nxt_date - now)}"
    else:
        footer = f"{months} months so far  |  maximum tier reached"

    avatar = await read_avatar(target)
    png = await asyncio.to_thread(
        render_tier_image, target.display_name, avatar, heading,
        (cur[2], cur[1]), (nxt[2], nxt[1]) if nxt else None, footer,
    )

    embed = discord.Embed(title=heading, colour=discord.Colour.blurple())
    embed.set_author(name=target.display_name, icon_url=target.display_avatar.url)
    embed.add_field(name=since_label, value=f"{ts(start, 'D')} ({months} month{'s' if months != 1 else ''})", inline=False)
    embed.add_field(name="Current badge", value=cur[1], inline=True)
    if nxt:
        embed.add_field(name="Next badge", value=nxt[1], inline=True)
        embed.add_field(name="Upgrades", value=f"{ts(nxt_date, 'R')} ({ts(nxt_date, 'F')})", inline=False)
    else:
        embed.add_field(name="Next badge", value="None, you're at the top tier.", inline=True)
    embed.set_footer(text=note)
    embed.set_image(url="attachment://tier.png")
    await interaction.followup.send(embed=embed, file=discord.File(io.BytesIO(png), "tier.png"))


# --------------------------------------------------------------------------- #
# Member count + message tracking
# --------------------------------------------------------------------------- #
@bot.tree.command(name="members", description="Show how many members this server has")
@app_commands.guild_only()
async def members_cmd(interaction: discord.Interaction):
    guild = interaction.guild
    embed = discord.Embed(title=guild.name, colour=discord.Colour.blurple())
    embed.add_field(name="Members", value=f"{guild.member_count:,}")
    monitored = bot.monitored.get(guild.id, set())
    embed.add_field(name="Channels tracked", value=str(len(monitored)))
    embed.add_field(name="Messages tracked", value=f"{bot.db.total_messages(guild.id):,}")
    if guild.icon:
        embed.set_thumbnail(url=guild.icon.url)
    await interaction.response.send_message(embed=embed)


@bot.tree.command(name="messages", description="How many messages a user has sent in the monitored channels")
@app_commands.describe(user="Defaults to you")
@app_commands.guild_only()
async def messages_cmd(interaction: discord.Interaction, user: Optional[discord.Member] = None):
    user = user or interaction.user
    guild = interaction.guild
    if not bot.monitored.get(guild.id):
        return await interaction.response.send_message(
            "No channels are being tracked yet. An admin can pick some with `/monitor setup`.", ephemeral=True)

    rows = bot.db.user_stats(guild.id, user.id)
    total = sum(n for _, n in rows)
    embed = discord.Embed(title=f"Messages from {user.display_name}", colour=discord.Colour.blurple())
    embed.set_thumbnail(url=user.display_avatar.url)
    embed.add_field(name="Total (tracked channels)", value=f"{total:,}", inline=False)
    if rows:
        lines = [f"<#{cid}>: **{n:,}**" for cid, n in rows[:10]]
        if len(rows) > 10:
            lines.append(f"...and {len(rows) - 10} more channel(s)")
        embed.add_field(name="By channel", value="\n".join(lines), inline=False)
    embed.set_footer(text="Counted since each channel was added to the monitor list.")
    await interaction.response.send_message(embed=embed)


@bot.tree.command(name="leaderboard", description="Top 10 message senders in the monitored channels")
@app_commands.guild_only()
async def leaderboard_cmd(interaction: discord.Interaction):
    guild = interaction.guild
    if not bot.monitored.get(guild.id):
        return await interaction.response.send_message(
            "No channels are being tracked yet. An admin can pick some with `/monitor setup`.", ephemeral=True)
    rows = bot.db.leaderboard(guild.id, 10)
    if not rows:
        return await interaction.response.send_message("No messages tracked yet.", ephemeral=True)
    medals = {1: "1.", 2: "2.", 3: "3."}
    lines = [f"`{medals.get(i, str(i) + '.')}` <@{uid}> **{total:,}**" for i, (uid, total) in enumerate(rows, 1)]
    embed = discord.Embed(title="Message leaderboard", description="\n".join(lines), colour=discord.Colour.gold())
    await interaction.response.send_message(embed=embed)


# --------------------------------------------------------------------------- #
# /monitor  (choose which channels are tracked)
# --------------------------------------------------------------------------- #
monitor = app_commands.Group(
    name="monitor",
    description="Choose which channels the bot counts messages in",
    guild_only=True,
    default_permissions=discord.Permissions(manage_guild=True),
)
bot.tree.add_command(monitor)


class ChannelPicker(discord.ui.View):
    def __init__(self, author_id: int):
        super().__init__(timeout=180)
        self.author_id = author_id

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.author_id:
            await interaction.response.send_message("This menu belongs to someone else.", ephemeral=True)
            return False
        return True

    @discord.ui.select(
        cls=discord.ui.ChannelSelect,
        channel_types=[discord.ChannelType.text, discord.ChannelType.news, discord.ChannelType.voice],
        placeholder="Select the channels to monitor...",
        min_values=1,
        max_values=25,
    )
    async def pick(self, interaction: discord.Interaction, select: discord.ui.ChannelSelect):
        ids = {c.id for c in select.values}
        bot.db.set_monitored(interaction.guild.id, ids)
        bot.monitored[interaction.guild.id] = ids
        mentions = " ".join(f"<#{i}>" for i in ids)
        await interaction.response.edit_message(
            content=f"Now monitoring {len(ids)} channel(s): {mentions}\n"
                    "Counting starts now. Use `/monitor backfill` to include older messages.",
            view=None,
        )

    async def on_timeout(self):
        self.stop()


@monitor.command(name="setup", description="Pick the channel(s) to monitor from a menu (replaces the current list)")
@app_commands.checks.has_permissions(manage_guild=True)
async def monitor_setup(interaction: discord.Interaction):
    await interaction.response.send_message(
        "Pick the channels to track (up to 25). This **replaces** the current selection.",
        view=ChannelPicker(interaction.user.id), ephemeral=True)


@monitor.command(name="all", description="Monitor every text channel in the server")
@app_commands.checks.has_permissions(manage_guild=True)
async def monitor_all(interaction: discord.Interaction):
    ids = {c.id for c in interaction.guild.text_channels}
    bot.db.set_monitored(interaction.guild.id, ids)
    bot.monitored[interaction.guild.id] = ids
    await interaction.response.send_message(f"Now monitoring all {len(ids)} text channels.", ephemeral=True)


@monitor.command(name="list", description="Show which channels are being monitored")
@app_commands.checks.has_permissions(manage_guild=True)
async def monitor_list(interaction: discord.Interaction):
    ids = bot.monitored.get(interaction.guild.id, set())
    text = " ".join(f"<#{i}>" for i in sorted(ids)) if ids else "No channels monitored."
    await interaction.response.send_message(text[:1990], ephemeral=True)


@monitor.command(name="clear", description="Stop monitoring all channels (stored counts are kept)")
@app_commands.checks.has_permissions(manage_guild=True)
async def monitor_clear(interaction: discord.Interaction):
    bot.db.set_monitored(interaction.guild.id, set())
    bot.monitored[interaction.guild.id] = set()
    await interaction.response.send_message("Monitoring stopped.", ephemeral=True)


@monitor.command(name="backfill", description="Recount existing messages in the monitored channels")
@app_commands.describe(limit="Max messages to read per channel (default 5000)")
@app_commands.checks.has_permissions(manage_guild=True)
async def monitor_backfill(interaction: discord.Interaction,
                           limit: app_commands.Range[int, 100, 50000] = 5000):
    guild = interaction.guild
    ids = bot.monitored.get(guild.id, set())
    if not ids:
        return await interaction.response.send_message("Select channels with `/monitor setup` first.", ephemeral=True)

    await interaction.response.defer(thinking=True, ephemeral=True)
    counted, skipped = 0, []
    for cid in sorted(ids):
        ch = guild.get_channel(cid)
        if ch is None or not isinstance(ch, discord.abc.Messageable):
            skipped.append(f"<#{cid}> (not found)")
            continue
        perms = ch.permissions_for(guild.me)
        if not (perms.view_channel and perms.read_message_history):
            skipped.append(f"<#{cid}> (missing View Channel / Read Message History)")
            continue
        counts: Counter = Counter()
        async for msg in ch.history(limit=limit):
            if not msg.author.bot:
                counts[msg.author.id] += 1
        bot.db.replace_channel_counts(guild.id, cid, counts)
        counted += sum(counts.values())

    text = f"Backfill done: {counted:,} messages counted (up to {limit:,} per channel)."
    if skipped:
        text += "\nSkipped: " + ", ".join(skipped)
    try:
        await interaction.followup.send(text, ephemeral=True)
    except discord.HTTPException:  # interaction token expired on a very long run
        await interaction.channel.send(text)


# --------------------------------------------------------------------------- #
# /badge
# --------------------------------------------------------------------------- #
def collect_badges(user: discord.User, member: Optional[discord.Member], nitro_since: Optional[datetime]):
    now = datetime.now(UTC)
    out = [(key, label) for attr, key, label in FLAG_BADGES if getattr(user.public_flags, attr, False)]
    if nitro_since:
        cur, _ = tier_for(NITRO_TIERS, full_months(nitro_since, now))
        out.append((cur[2], f"Nitro {cur[1]}"))
    if member and member.premium_since:
        cur, _ = tier_for(BOOST_TIERS, full_months(member.premium_since, now))
        out.append((cur[2], f"Server {cur[1]}"))
    return out


@bot.tree.command(name="badge", description="Generate an image of a user's profile badges")
@app_commands.describe(user="Defaults to you")
async def badge_cmd(interaction: discord.Interaction, user: Optional[discord.User] = None):
    await interaction.response.defer()
    target = user or interaction.user
    full_user = await bot.fetch_user(target.id)  # fresh copy so public_flags is populated
    member = await resolve_member(interaction.guild, target.id)
    badges = collect_badges(full_user, member, bot.db.get_nitro_since(target.id))

    avatar = await read_avatar(member or full_user)
    name = member.display_name if member else full_user.display_name
    png = await asyncio.to_thread(render_badges_image, name, avatar, badges)

    embed = discord.Embed(title=f"Badges of {name}", colour=discord.Colour.blurple())
    embed.description = "\n".join(f"- {label}" for _, label in badges) or "No badges found."
    embed.set_footer(text="Nitro and booster badges are inferred (registered date / this server only). "
                          "Discord does not expose the full profile badge list to bots.")
    embed.set_image(url="attachment://badges.png")
    await interaction.followup.send(embed=embed, file=discord.File(io.BytesIO(png), "badges.png"))


# --------------------------------------------------------------------------- #
# /nitro  (self-registered start date) and /boost  (real data, this server only)
# --------------------------------------------------------------------------- #
@bot.tree.command(name="nitro_set", description="Register the date your Nitro subscription started (YYYY-MM-DD)")
@app_commands.describe(date="Your Nitro start date, e.g. 2023-04-17 (shown in your profile's badge tooltip)")
async def nitro_set_cmd(interaction: discord.Interaction, date: str):
    try:
        start = datetime.strptime(date.strip(), "%Y-%m-%d").replace(tzinfo=UTC)
    except ValueError:
        return await interaction.response.send_message("Use the format `YYYY-MM-DD`, e.g. `2023-04-17`.", ephemeral=True)
    if start > datetime.now(UTC) or start.year < 2016:
        return await interaction.response.send_message("That date doesn't look right.", ephemeral=True)
    bot.db.set_nitro_since(interaction.user.id, start)
    await interaction.response.send_message(
        f"Saved. Anyone can now run `/nitro` on you. Delete it any time with `/nitro_forget`.", ephemeral=True)


@bot.tree.command(name="nitro_forget", description="Delete your registered Nitro start date")
async def nitro_forget_cmd(interaction: discord.Interaction):
    bot.db.forget_nitro(interaction.user.id)
    await interaction.response.send_message("Your Nitro date has been deleted.", ephemeral=True)


@bot.tree.command(name="nitro", description="Nitro months and time until the next Nitro badge")
@app_commands.describe(user="Defaults to you")
async def nitro_cmd(interaction: discord.Interaction, user: Optional[discord.User] = None):
    target = user or interaction.user
    start = bot.db.get_nitro_since(target.id)
    if start is None:
        who = "You haven't" if target.id == interaction.user.id else f"{target.display_name} hasn't"
        return await interaction.response.send_message(
            f"{who} registered a Nitro start date. Discord doesn't let bots see Nitro status, "
            "so the date has to be registered by the user with `/nitro_set YYYY-MM-DD` "
            "(hover your Nitro badge in your profile to see it).", ephemeral=True)
    await interaction.response.defer()
    await send_tier_card(
        interaction, target, tiers=NITRO_TIERS, start=start,
        heading="Nitro badge progress", since_label="Nitro since",
        note="Based on the start date this user registered, not read from Discord.")


@bot.tree.command(name="boost", description="How long a member has boosted THIS server, and their next boost badge")
@app_commands.describe(user="Defaults to you")
@app_commands.guild_only()
async def boost_cmd(interaction: discord.Interaction, user: Optional[discord.User] = None):
    target = user or interaction.user
    member = await resolve_member(interaction.guild, target.id)
    if member is None or not member.premium_since:
        return await interaction.response.send_message(
            f"{target.display_name} isn't boosting this server.", ephemeral=True)
    await interaction.response.defer()
    await send_tier_card(
        interaction, member, tiers=BOOST_TIERS, start=member.premium_since,
        heading="Server boost badge progress", since_label="Boosting this server since",
        note="Only counts boosts on this server; the real badge counts boosting across all servers.")


# --------------------------------------------------------------------------- #
def main():
    if not TOKEN:
        raise SystemExit("DISCORD_TOKEN is missing. Copy .env.example to .env and fill it in.")
    bot.run(TOKEN)


if __name__ == "__main__":
    main()
